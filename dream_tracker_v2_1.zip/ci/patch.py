"""Android config patches for the speech-to-text plugin. Fails loudly if the
generated project does not look as expected."""
import pathlib
import re
import sys


def read(p):
    return pathlib.Path(p).read_text(encoding='utf-8')


def write(p, s):
    pathlib.Path(p).write_text(s, encoding='utf-8')


log = []

# ---- AndroidManifest.xml ----
mp = 'android/app/src/main/AndroidManifest.xml'
m = read(mp)
if '<application' not in m:
    sys.exit('AndroidManifest.xml has no <application> tag')
m = re.sub(r'android:label="[^"]*"', 'android:label="Dream Tracker"', m, count=1)
need = []
for perm in ('RECORD_AUDIO', 'INTERNET'):
    if 'android.permission.' + perm not in m:
        need.append('    <uses-permission android:name="android.permission.%s"/>\n' % perm)
if need:
    m = m.replace('<application', ''.join(need) + '    <application', 1)
    log.append('permissions added: %d' % len(need))
if 'android.speech.RecognitionService' not in m:
    intent = ('<intent>\n            <action android:name="android.speech.RecognitionService"/>\n'
              '        </intent>')
    if '<queries>' in m:
        m = m.replace('<queries>', '<queries>\n        ' + intent, 1)
    else:
        m = m.replace('</manifest>', '    <queries>\n        ' + intent + '\n    </queries>\n</manifest>', 1)
    log.append('speech queries added')
write(mp, m)

# ---- app/build.gradle(.kts): minSdk ----
gp = None
for cand in ('android/app/build.gradle.kts', 'android/app/build.gradle'):
    if pathlib.Path(cand).exists():
        gp = cand
        break
if gp is None:
    sys.exit('no android/app/build.gradle(.kts) found')
g = read(gp)
g2, n = re.subn(r'(minSdk(?:Version)?\s*=?\s*)flutter\.minSdkVersion', r'\g<1>26', g)
if n:
    write(gp, g2)
    log.append('minSdk set to 26 in ' + gp)
else:
    log.append('minSdk line not replaced (already custom?) in ' + gp)

print('; '.join(log))
