#!/usr/bin/env bash
# Runs inside the GitHub runner after `flutter create` and unzip.
set -o pipefail
REPORT=build_report.md
echo "### Dream Tracker build" > "$REPORT"

fail() {
  { echo; echo "**$1**"; echo '```'; tail -n 45 "$2"; echo '```'; } >> "$REPORT"
  exit 1
}

python3 ci/patch.py > patch.log 2>&1 || fail "Android patch failed" patch.log
cat patch.log >> "$REPORT"

{
  flutter pub add shared_preferences speech_to_text
  flutter pub add dev:flutter_launcher_icons
  cat >> pubspec.yaml <<'EOF'

flutter_launcher_icons:
  android: true
  ios: false
  image_path: "assets/icon.png"
  adaptive_icon_background: "assets/icon_bg.png"
  adaptive_icon_foreground: "assets/icon_fg.png"
EOF
  flutter pub get
  dart run flutter_launcher_icons
} > setup.log 2>&1 || fail "Dependency setup failed" setup.log

rm -rf test
flutter analyze --no-pub > analyze.log 2>&1
grep -E '^\s*error' analyze.log | head -n 30 > errors.log
if [ -s errors.log ]; then
  { echo; echo "**Dart errors**"; echo '```'; cat errors.log; echo '```'; } >> "$REPORT"
fi

flutter build apk --release > build.log 2>&1
code=$?
if [ $code -ne 0 ]; then
  grep -n -E 'FAILURE|What went wrong|Execution failed|error:|Error:' -A3 build.log | head -n 60 > gradle_errors.log
  [ -s gradle_errors.log ] || tail -n 40 build.log > gradle_errors.log
  { echo; echo "**Build failed**"; echo '```'; cat gradle_errors.log; echo '```'; } >> "$REPORT"
  exit $code
fi
echo "Build OK" >> "$REPORT"
