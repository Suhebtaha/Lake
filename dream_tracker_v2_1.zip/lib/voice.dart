import 'dart:async';

import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';

import 'editor.dart';
import 'glass.dart';
import 'models.dart';

Future<void> showVoiceSheet(BuildContext context, Store store) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => VoiceSheet(store: store, parentContext: context),
  );
}

class VoiceSheet extends StatefulWidget {
  final Store store;
  final BuildContext parentContext;
  const VoiceSheet({super.key, required this.store, required this.parentContext});

  @override
  State<VoiceSheet> createState() => _VoiceSheetState();
}

class _VoiceSheetState extends State<VoiceSheet>
    with SingleTickerProviderStateMixin {
  // Dynamic on purpose: the plugin's API can change between releases, and a
  // mismatch then fails at runtime (caught below) instead of breaking the build.
  final dynamic _stt = SpeechToText();
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
  );

  bool _ready = false;
  bool _active = false;
  bool _listening = false;
  String _text = '';
  String _live = '';
  String _error = '';
  String _lang = 'en';
  int _errors = 0;
  List<dynamic> _locales = [];
  Timer? _restart;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _active = false;
    _restart?.cancel();
    _pulse.dispose();
    try {
      _stt.cancel();
    } catch (_) {}
    super.dispose();
  }

  Future<void> _init() async {
    try {
      final ok = await _stt.initialize(onStatus: _onStatus, onError: _onError);
      if (!mounted) return;
      if (ok != true) {
        setState(() => _error =
            'Speech recognition is not available. Allow the microphone and make sure the Google app is installed.');
        return;
      }
      try {
        final l = await _stt.locales();
        _locales = List<dynamic>.from(l as List);
      } catch (_) {}
      if (!mounted) return;
      setState(() => _ready = true);
      _begin();
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'Could not start speech recognition.');
      }
    }
  }

  String? _localeId() {
    final wants = _lang == 'ku' ? ['ckb', 'ku'] : [_lang];
    for (final w in wants) {
      if (w == 'en') {
        for (final l in _locales) {
          try {
            final id = l.localeId as String;
            if (id.toLowerCase().replaceAll('-', '_') == 'en_us') return id;
          } catch (_) {}
        }
      }
      for (final l in _locales) {
        try {
          final id = l.localeId as String;
          if (id.toLowerCase().replaceAll('-', '_').startsWith(w)) return id;
        } catch (_) {}
      }
    }
    return null;
  }

  void _begin() {
    _active = true;
    _errors = 0;
    _pulse.repeat(reverse: true);
    _listen();
  }

  Future<void> _listen() async {
    if (!_active || !mounted) return;
    final id = _localeId();
    setState(() {
      _listening = true;
      _error = '';
    });
    try {
      try {
        await _stt.listen(
          onResult: _onResult,
          localeId: id,
          listenFor: const Duration(minutes: 3),
          pauseFor: const Duration(seconds: 6),
        );
      } catch (_) {
        await _stt.listen(onResult: _onResult);
      }
    } catch (_) {
      _pulse.stop();
      if (mounted) {
        setState(() {
          _listening = false;
          _active = false;
          _error = 'Could not start listening.';
        });
      }
    }
  }

  void _commit(String words) {
    final w = words.trim();
    if (w.isNotEmpty && !_text.endsWith(w)) {
      _text = _text.isEmpty ? w : '$_text $w';
    }
    _live = '';
  }

  void _onResult(dynamic r) {
    var words = '';
    var fin = false;
    try {
      words = (r.recognizedWords as String?) ?? '';
      fin = r.finalResult == true;
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      if (fin) {
        _commit(words);
      } else {
        _live = words;
      }
    });
  }

  void _scheduleRestart() {
    _restart?.cancel();
    if (!_active) return;
    _restart = Timer(const Duration(milliseconds: 400), _listen);
  }

  void _onStatus(String s) {
    if (!mounted) return;
    if (s == 'done' || s == 'notListening') {
      if (_live.isNotEmpty) {
        final l = _live;
        setState(() => _commit(l));
      }
      if (_active) {
        _scheduleRestart();
      } else {
        setState(() => _listening = false);
      }
    }
  }

  void _onError(dynamic e) {
    var msg = '';
    try {
      msg = (e.errorMsg as String?) ?? '';
    } catch (_) {
      msg = e.toString();
    }
    if (!mounted) return;
    if (msg.contains('permission')) {
      _stopQuiet('Microphone permission is needed to record your dream.');
      return;
    }
    final benign = msg.contains('no_match') || msg.contains('timeout');
    if (_errors < (benign ? 10 : 3)) {
      _errors++;
      _scheduleRestart();
    } else {
      _stopQuiet('Speech recognition stopped. Tap the mic to try again.');
    }
  }

  void _stopQuiet(String message) {
    _active = false;
    _restart?.cancel();
    _pulse.stop();
    setState(() {
      _listening = false;
      _error = message;
      if (_live.isNotEmpty) _commit(_live);
    });
  }

  Future<void> _halt() async {
    _active = false;
    _restart?.cancel();
    _pulse.stop();
    try {
      await _stt.stop();
    } catch (_) {}
    if (mounted) {
      setState(() {
        _listening = false;
        if (_live.isNotEmpty) _commit(_live);
      });
    }
  }

  void _toggle() {
    if (!_ready) return;
    if (_active) {
      _halt();
    } else {
      _begin();
    }
  }

  Future<void> _changeLang(String l) async {
    if (_lang == l) return;
    final wasActive = _active;
    await _halt();
    if (!mounted) return;
    setState(() => _lang = l);
    if (wasActive) _begin();
  }

  Future<void> _save({required bool edit}) async {
    await _halt();
    if (!mounted) return;
    final text = _text.trim();
    if (text.isEmpty) {
      setState(() => _error = 'Nothing recorded yet. Tap the mic and speak.');
      return;
    }
    final nav = Navigator.of(context);
    final parent = widget.parentContext;
    nav.pop();
    if (edit) {
      Navigator.of(parent).push(
        MaterialPageRoute(
          builder: (_) => EditorScreen(store: widget.store, initialBody: text),
        ),
      );
      return;
    }
    final first = text.split('\n').first.trim();
    final title = first.length > 40 ? '${first.substring(0, 40)}...' : first;
    widget.store.upsert(Dream(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: title,
      body: text,
      date: DateTime.now(),
    ));
    ScaffoldMessenger.of(parent).showSnackBar(
      const SnackBar(content: Text('Dream saved')),
    );
  }

  Widget _chip(String label, String code) {
    final sel = _lang == code;
    return GestureDetector(
      onTap: () => _changeLang(code),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: sel ? C.accent.withAlpha(140) : Colors.white.withAlpha(16),
          border: Border.all(color: Colors.white.withAlpha(sel ? 110 : 40)),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: sel ? Colors.white : C.sub,
          ),
        ),
      ),
    );
  }

  String _status() {
    if (_error.isNotEmpty) return _error;
    if (!_ready) return 'Starting...';
    if (_listening) return 'Listening... speak freely';
    return 'Paused. Tap the mic to continue';
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final shown = '$_text $_live'.trim();
    return Container(
      constraints: BoxConstraints(maxHeight: mq.size.height * 0.85),
      padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + mq.viewPadding.bottom),
      decoration: BoxDecoration(
        color: const Color(0xFF12164A),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        border: Border(top: BorderSide(color: Colors.white.withAlpha(50))),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 44,
            height: 5,
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(60),
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Record your dream',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          Text(
            _status(),
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: _error.isNotEmpty ? const Color(0xFFFF8A8A) : C.sub,
            ),
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _chip('English', 'en'),
              const SizedBox(width: 8),
              _chip('العربية', 'ar'),
              const SizedBox(width: 8),
              _chip('کوردی', 'ku'),
            ],
          ),
          const SizedBox(height: 16),
          AnimatedBuilder(
            animation: _pulse,
            builder: (context, child) {
              final t = _listening ? _pulse.value : 0.0;
              return Container(
                width: 124,
                height: 124,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: C.accent.withAlpha(24 + (t * 50).round()),
                ),
                child: child,
              );
            },
            child: GestureDetector(
              onTap: _toggle,
              child: Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF7A6BFF), Color(0xFFB06BFF)],
                  ),
                  boxShadow: [
                    BoxShadow(color: C.accent.withAlpha(140), blurRadius: 22),
                  ],
                ),
                child: Icon(
                  _listening ? Icons.stop_rounded : Icons.mic_rounded,
                  color: Colors.white,
                  size: 40,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Flexible(
            child: Glass(
              radius: 22,
              padding: const EdgeInsets.all(16),
              child: SingleChildScrollView(
                child: SizedBox(
                  width: double.infinity,
                  child: shown.isEmpty
                      ? const Text(
                          'Your words will appear here...',
                          style: TextStyle(color: C.sub, height: 1.5),
                        )
                      : Text(
                          shown,
                          textDirection: dirOf(shown),
                          style: const TextStyle(fontSize: 16, height: 1.6),
                        ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: Glass(
                  onTap: () => _save(edit: true),
                  radius: 28,
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  child: const Center(
                    child: Text(
                      'Edit',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: GradientButton(
                  label: 'Save dream',
                  onTap: () => _save(edit: false),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
