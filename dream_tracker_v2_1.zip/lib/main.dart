import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'calendar.dart';
import 'detail.dart';
import 'editor.dart';
import 'glass.dart';
import 'home.dart';
import 'liquid.dart';
import 'models.dart';
import 'stats.dart';
import 'voice.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  final store = Store();
  await store.load();
  runApp(DreamApp(store: store));
}

class DreamApp extends StatelessWidget {
  final Store store;
  const DreamApp({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dream Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: C.bg1,
        colorScheme: ColorScheme.fromSeed(
          seedColor: C.accent,
          brightness: Brightness.dark,
        ),
        textTheme: ThemeData.dark().textTheme.apply(
              bodyColor: C.text,
              displayColor: C.text,
            ),
      ),
      home: Splash(store: store),
    );
  }
}

class Splash extends StatefulWidget {
  final Store store;
  const Splash({super.key, required this.store});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2200), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 600),
          pageBuilder: (_, __, ___) => Shell(store: widget.store),
          transitionsBuilder: (_, a, __, child) =>
              FadeTransition(opacity: a, child: child),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NightBackground(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Text(
                'Dream Tracker',
                style: TextStyle(fontSize: 38, fontWeight: FontWeight.w300),
              ),
              SizedBox(height: 14),
              Text(
                'Remember your dreams.\nDiscover your mind.',
                textAlign: TextAlign.center,
                style: TextStyle(color: C.sub, fontSize: 16, height: 1.5),
              ),
              SizedBox(height: 60),
              MoonGlow(size: 150),
            ],
          ),
        ),
      ),
    );
  }
}

class Shell extends StatefulWidget {
  final Store store;
  const Shell({super.key, required this.store});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;

  void _edit([Dream? d]) => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => EditorScreen(store: widget.store, dream: d),
        ),
      );

  void _view(Dream d) => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DetailScreen(store: widget.store, dream: d),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final s = widget.store;
    final pad = MediaQuery.of(context).padding;
    return Scaffold(
      body: NightBackground(
        child: ListenableBuilder(
          listenable: s,
          builder: (context, _) {
            final screens = <Widget>[
              HomeScreen(
                store: s,
                onOpen: _view,
                onNew: _edit,
                onProfile: () => setState(() => _tab = 3),
              ),
              CalendarScreen(store: s, onOpen: _view),
              StatsScreen(store: s),
              ProfileScreen(store: s),
            ];
            return Stack(
              children: [
                Positioned.fill(
                  child: Padding(
                    padding: EdgeInsets.only(top: pad.top),
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      child: KeyedSubtree(
                        key: ValueKey(_tab),
                        child: screens[_tab],
                      ),
                    ),
                  ),
                ),
                if (_tab == 0)
                  Positioned(
                    right: 22,
                    bottom: pad.bottom + 112,
                    child: GestureDetector(
                      onTap: _edit,
                      child: Container(
                        width: 58,
                        height: 58,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [Color(0xFF5B6CFF), Color(0xFF8E6BFF)],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: C.accent.withAlpha(130),
                              blurRadius: 22,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.add, color: Colors.white, size: 30),
                      ),
                    ),
                  ),
                Positioned(
                  left: 16,
                  right: 16,
                  bottom: pad.bottom + 14,
                  child: GlassNav(
                    index: _tab,
                    onChanged: (i) => setState(() => _tab = i),
                    onMic: () => showVoiceSheet(context, s),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
