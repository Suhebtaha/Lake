import 'dart:ui';

import 'package:flutter/material.dart';

import 'glass.dart';

/// Liquid Glass segmented button: a blurred glass pill with a glass thumb
/// that slides, stretches and bounces. Supports tap and drag.
class GlassSegmented extends StatefulWidget {
  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;
  const GlassSegmented({
    super.key,
    required this.labels,
    required this.index,
    required this.onChanged,
  });

  @override
  State<GlassSegmented> createState() => _GlassSegmentedState();
}

class _GlassSegmentedState extends State<GlassSegmented> {
  double? _drag;

  @override
  Widget build(BuildContext context) {
    final n = widget.labels.length;
    return LayoutBuilder(
      builder: (context, c) {
        final seg = (c.maxWidth - 8) / n;
        final dragging = _drag != null;
        final pos = _drag ?? widget.index.toDouble();
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (d) {
            final i = ((d.localPosition.dx - 4) / seg).floor().clamp(0, n - 1).toInt();
            widget.onChanged(i);
          },
          onHorizontalDragStart: (_) =>
              setState(() => _drag = widget.index.toDouble()),
          onHorizontalDragUpdate: (d) => setState(() {
            _drag = ((_drag ?? 0) + d.delta.dx / seg)
                .clamp(0.0, n - 1.0)
                .toDouble();
          }),
          onHorizontalDragEnd: (_) {
            final i = (_drag ?? 0).round();
            setState(() => _drag = null);
            widget.onChanged(i);
          },
          onHorizontalDragCancel: () => setState(() => _drag = null),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(26),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                height: 52,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(26),
                  color: Colors.white.withAlpha(16),
                  border: Border.all(color: Colors.white.withAlpha(40)),
                ),
                child: Stack(
                  children: [
                    AnimatedPositioned(
                      duration: dragging
                          ? Duration.zero
                          : const Duration(milliseconds: 420),
                      curve: Curves.easeOutBack,
                      left: pos * seg,
                      top: 0,
                      bottom: 0,
                      width: seg,
                      child: AnimatedScale(
                        scale: dragging ? 1.1 : 1.0,
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOut,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(22),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withAlpha(90),
                                C.accent.withAlpha(90),
                              ],
                            ),
                            border: Border.all(color: Colors.white.withAlpha(110)),
                            boxShadow: [
                              BoxShadow(
                                color: C.accent.withAlpha(90),
                                blurRadius: 16,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: Row(
                        children: [
                          for (var i = 0; i < n; i++)
                            Expanded(
                              child: Center(
                                child: AnimatedDefaultTextStyle(
                                  duration: const Duration(milliseconds: 200),
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: pos.round() == i ? Colors.white : C.sub,
                                  ),
                                  child: Text(widget.labels[i]),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Bottom bar: iOS-style sliding glass thumb (tap or drag) with a raised
/// quick-record microphone button in the middle.
class GlassNav extends StatefulWidget {
  final int index;
  final ValueChanged<int> onChanged;
  final VoidCallback onMic;
  const GlassNav({
    super.key,
    required this.index,
    required this.onChanged,
    required this.onMic,
  });

  @override
  State<GlassNav> createState() => _GlassNavState();
}

class _GlassNavState extends State<GlassNav> {
  static const items = [
    (Icons.home_rounded, 'Home'),
    (Icons.calendar_month_rounded, 'Calendar'),
    (Icons.bar_chart_rounded, 'Stats'),
    (Icons.person_rounded, 'Profile'),
  ];

  // Five slots: tab0, tab1, [mic], tab2, tab3.
  static int _slotOf(int tab) => tab < 2 ? tab : tab + 1;
  static int _tabOf(int slot) => slot < 2 ? slot : slot - 1;

  double? _drag;

  void _finishDrag() {
    final d = _drag;
    if (d == null) return;
    var slot = d.round();
    if (slot == 2) slot = d < 2 ? 1 : 3;
    setState(() => _drag = null);
    widget.onChanged(_tabOf(slot));
  }

  Widget _item(int slot, int shownSlot) {
    final tab = _tabOf(slot);
    final sel = shownSlot == slot;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => widget.onChanged(tab),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 32,
            child: Center(
              child: Icon(
                items[tab].$1,
                size: 22,
                color: sel ? Colors.white : C.sub,
              ),
            ),
          ),
          const SizedBox(height: 1),
          Text(
            items[tab].$2,
            style: TextStyle(fontSize: 11, color: sel ? Colors.white : C.sub),
          ),
        ],
      ),
    );
  }

  Widget _bar() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(34),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          height: 68,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(34),
            color: Colors.white.withAlpha(20),
            border: Border.all(color: Colors.white.withAlpha(46)),
          ),
          child: LayoutBuilder(
            builder: (context, c) {
              final slot = c.maxWidth / 5;
              final dragging = _drag != null;
              final pos = _drag ?? _slotOf(widget.index).toDouble();
              final shown = pos.round();
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onHorizontalDragStart: (_) =>
                    setState(() => _drag = _slotOf(widget.index).toDouble()),
                onHorizontalDragUpdate: (d) => setState(() {
                  _drag = ((_drag ?? 0) + d.delta.dx / slot)
                      .clamp(0.0, 4.0)
                      .toDouble();
                }),
                onHorizontalDragEnd: (_) => _finishDrag(),
                onHorizontalDragCancel: () => setState(() => _drag = null),
                child: Stack(
                  children: [
                    AnimatedPositioned(
                      duration: dragging
                          ? Duration.zero
                          : const Duration(milliseconds: 380),
                      curve: Curves.easeOutBack,
                      left: pos * slot + (slot - 58) / 2,
                      top: 10,
                      width: 58,
                      height: 34,
                      child: AnimatedScale(
                        scale: dragging ? 1.15 : 1.0,
                        duration: const Duration(milliseconds: 200),
                        curve: Curves.easeOut,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(17),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withAlpha(80),
                                C.accent.withAlpha(120),
                              ],
                            ),
                            border: Border.all(color: Colors.white.withAlpha(100)),
                            boxShadow: [
                              BoxShadow(
                                color: C.accent.withAlpha(90),
                                blurRadius: 14,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: Row(
                        children: [
                          for (var s = 0; s < 5; s++)
                            Expanded(
                              child: s == 2
                                  ? const SizedBox.shrink()
                                  : _item(s, shown),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _mic() {
    return Semantics(
      button: true,
      label: 'Record a dream with your voice',
      child: GestureDetector(
        onTap: widget.onMic,
        child: Container(
          width: 68,
          height: 68,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF7A6BFF), Color(0xFFB06BFF)],
            ),
            border: Border.all(color: Colors.white.withAlpha(120), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: C.accent.withAlpha(150),
                blurRadius: 24,
                spreadRadius: 1,
              ),
            ],
          ),
          child: const Icon(Icons.mic_rounded, color: Colors.white, size: 32),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 92,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned(left: 0, right: 0, bottom: 0, child: _bar()),
          Positioned(top: 0, left: 0, right: 0, child: Center(child: _mic())),
        ],
      ),
    );
  }
}
