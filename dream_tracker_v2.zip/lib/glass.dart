import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';

import 'models.dart';

class C {
  static const bg1 = Color(0xFF04051A);
  static const bg2 = Color(0xFF0A0F36);
  static const bg3 = Color(0xFF1A1650);
  static const accent = Color(0xFF6D63FF);
  static const accent2 = Color(0xFF9C8CFF);
  static const text = Color(0xFFEEF0FF);
  static const sub = Color(0xFF9EA5D6);
}

class NightBackground extends StatelessWidget {
  final Widget child;
  const NightBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [C.bg3, C.bg2, C.bg1],
              ),
            ),
          ),
        ),
        Positioned.fill(child: CustomPaint(painter: _StarsPainter())),
        Positioned.fill(child: child),
      ],
    );
  }
}

class _StarsPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final r = Random(11);
    final p = Paint();
    for (var i = 0; i < 80; i++) {
      p.color = Colors.white.withAlpha(30 + r.nextInt(130));
      canvas.drawCircle(
        Offset(r.nextDouble() * size.width, r.nextDouble() * size.height * 0.75),
        0.4 + r.nextDouble() * 1.1,
        p,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final VoidCallback? onTap;
  const Glass({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 22,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final box = ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.white.withAlpha(34), Colors.white.withAlpha(10)],
            ),
            border: Border.all(color: Colors.white.withAlpha(46)),
          ),
          child: child,
        ),
      ),
    );
    if (onTap == null) return box;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: box,
    );
  }
}

class GlassIcon extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const GlassIcon(this.icon, {super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Glass(
      onTap: onTap,
      radius: 22,
      padding: const EdgeInsets.all(10),
      child: Icon(icon, color: C.text, size: 22),
    );
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const GradientButton({super.key, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 56,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(
            colors: [Color(0xFF5B6CFF), Color(0xFF8E6BFF)],
          ),
          boxShadow: [
            BoxShadow(
              color: C.accent.withAlpha(110),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String label;
  final IconData? icon;
  const Pill(this.label, {super.key, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white.withAlpha(18),
        border: Border.all(color: Colors.white.withAlpha(40)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 15, color: C.accent2),
            const SizedBox(width: 6),
          ],
          Text(label, style: const TextStyle(fontSize: 13, color: C.text)),
        ],
      ),
    );
  }
}

class DText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final int? maxLines;
  const DText(this.text, {super.key, this.style, this.maxLines});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Text(
        text,
        textDirection: dirOf(text),
        maxLines: maxLines,
        overflow: maxLines == null ? null : TextOverflow.ellipsis,
        style: style,
      ),
    );
  }
}

class MoonGlow extends StatelessWidget {
  final double size;
  const MoonGlow({super.key, this.size = 120});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [C.accent2.withAlpha(120), C.accent.withAlpha(30), Colors.transparent],
        ),
        boxShadow: [
          BoxShadow(color: C.accent.withAlpha(90), blurRadius: 50, spreadRadius: 4),
        ],
      ),
      child: Icon(Icons.nightlight_round, size: size * 0.5, color: Colors.white),
    );
  }
}

class DreamArt extends StatelessWidget {
  final String seed;
  final double size;
  const DreamArt({super.key, required this.seed, this.size = 54});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: paletteFor(seed),
        ),
      ),
      child: Icon(
        Icons.nightlight_round,
        color: Colors.white.withAlpha(200),
        size: size * 0.45,
      ),
    );
  }
}

class DreamTile extends StatelessWidget {
  final Dream d;
  final VoidCallback onTap;
  const DreamTile(this.d, {super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Glass(
      onTap: onTap,
      radius: 20,
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          DreamArt(seed: d.id),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                DText(
                  d.title,
                  maxLines: 1,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Text(
                  fmtDay(d.date),
                  style: const TextStyle(fontSize: 12, color: C.sub),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: C.sub),
        ],
      ),
    );
  }
}
