import 'package:flutter/material.dart';

import 'glass.dart';
import 'models.dart';

class EditorScreen extends StatefulWidget {
  final Store store;
  final Dream? dream;
  const EditorScreen({super.key, required this.store, this.dream});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late final TextEditingController _title;
  late final TextEditingController _body;
  late final TextEditingController _notes;
  late DateTime _date;
  late List<String> _people;
  late List<String> _places;
  late List<String> _emotions;
  late List<String> _tags;

  @override
  void initState() {
    super.initState();
    final d = widget.dream;
    _title = TextEditingController(text: d?.title ?? '');
    _body = TextEditingController(text: d?.body ?? '');
    _notes = TextEditingController(text: d?.notes ?? '');
    _date = d?.date ?? DateTime.now();
    _people = [...?d?.people];
    _places = [...?d?.places];
    _emotions = [...?d?.emotions];
    _tags = [...?d?.tags];
  }

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    _notes.dispose();
    super.dispose();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  void _save() {
    final body = _body.text.trim();
    var title = _title.text.trim();
    if (body.isEmpty && title.isEmpty) {
      _snack('Write something about your dream first');
      return;
    }
    if (title.isEmpty) {
      final first = body.split('\n').first.trim();
      title = first.length > 40 ? '${first.substring(0, 40)}...' : first;
    }
    widget.store.upsert(Dream(
      id: widget.dream?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      title: title,
      body: body,
      date: _date,
      people: _people,
      places: _places,
      emotions: _emotions,
      tags: _tags,
      notes: _notes.text.trim(),
    ));
    Navigator.pop(context);
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 1)),
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_date),
    );
    if (t == null || !mounted) return;
    setState(() => _date = DateTime(d.year, d.month, d.day, t.hour, t.minute));
  }

  Future<void> _editList(
    String name,
    List<String> cur,
    void Function(List<String>) set,
  ) async {
    final c = TextEditingController(text: cur.join(', '));
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: const BoxDecoration(
            color: Color(0xFF12164A),
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              const Text('Separate items with commas', style: TextStyle(color: C.sub)),
              const SizedBox(height: 14),
              TextField(
                controller: c,
                autofocus: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white.withAlpha(18),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              GradientButton(label: 'Done', onTap: () => Navigator.pop(ctx, true)),
            ],
          ),
        ),
      ),
    );
    if (ok == true) setState(() => set(parseList(c.text)));
  }

  Widget _field(
    TextEditingController c,
    String hint,
    int minLines,
    int maxLines, {
    Widget? suffix,
  }) {
    return Glass(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: TextField(
              controller: c,
              minLines: minLines,
              maxLines: maxLines,
              onChanged: (_) => setState(() {}),
              textDirection: dirOf(c.text),
              style: const TextStyle(fontSize: 16, height: 1.5),
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: hint,
                hintStyle: const TextStyle(color: C.sub),
              ),
            ),
          ),
          if (suffix != null) suffix,
        ],
      ),
    );
  }

  Widget _detail(
    IconData icon,
    String name,
    List<String> cur,
    void Function(List<String>) set,
  ) {
    return Glass(
      onTap: () => _editList(name, cur, set),
      radius: 20,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
      child: Row(
        children: [
          Icon(icon, color: C.accent2, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              cur.isEmpty ? name : '$name · ${cur.length}',
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.dream != null;
    final hasChips =
        _people.isNotEmpty || _places.isNotEmpty || _emotions.isNotEmpty || _tags.isNotEmpty;
    return Scaffold(
      body: NightBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
            children: [
              Row(
                children: [
                  GlassIcon(Icons.arrow_back, onTap: () => Navigator.pop(context)),
                  Expanded(
                    child: Text(
                      editing ? 'Edit Dream' : 'New Dream',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(width: 44),
                ],
              ),
              const SizedBox(height: 28),
              const Text(
                'What did you dream about?',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              const Text(
                'Write everything you remember...\nno detail is too small.',
                style: TextStyle(color: C.sub, height: 1.4),
              ),
              const SizedBox(height: 20),
              _field(_title, 'Title (optional)', 1, 1),
              const SizedBox(height: 12),
              _field(
                _body,
                'Type here...',
                7,
                12,
                suffix: Padding(
                  padding: const EdgeInsets.only(top: 14),
                  child: GestureDetector(
                    onTap: () => _snack('Tip: tap the microphone on your keyboard to dictate'),
                    child: const Icon(Icons.mic_none, color: C.sub),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Add details (optional)',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _detail(Icons.person_outline, 'People', _people, (v) => _people = v)),
                  const SizedBox(width: 12),
                  Expanded(child: _detail(Icons.place_outlined, 'Places', _places, (v) => _places = v)),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _detail(Icons.mood, 'Emotions', _emotions, (v) => _emotions = v)),
                  const SizedBox(width: 12),
                  Expanded(child: _detail(Icons.sell_outlined, 'Tags', _tags, (v) => _tags = v)),
                ],
              ),
              if (hasChips)
                Padding(
                  padding: const EdgeInsets.only(top: 14),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final t in _people) Pill(t, icon: Icons.person_outline),
                      for (final t in _places) Pill(t, icon: Icons.place_outlined),
                      for (final t in _emotions) Pill(t, icon: Icons.mood),
                      for (final t in _tags) Pill(t, icon: Icons.sell_outlined),
                    ],
                  ),
                ),
              const SizedBox(height: 18),
              Glass(
                onTap: _pickDate,
                radius: 20,
                child: Row(
                  children: [
                    const Icon(Icons.schedule, color: C.accent2, size: 22),
                    const SizedBox(width: 12),
                    Expanded(child: Text('${fmtDay(_date)} · ${fmtTime(_date)}')),
                    const Icon(Icons.edit_calendar_outlined, color: C.sub, size: 20),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              _field(_notes, 'Notes (optional)', 2, 5),
              const SizedBox(height: 28),
              GradientButton(label: 'Save Dream', onTap: _save),
            ],
          ),
        ),
      ),
    );
  }
}
