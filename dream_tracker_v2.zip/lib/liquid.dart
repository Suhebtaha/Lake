import 'dart:ui';

import 'package:flutter/material.dart';

import 'glass.dart';

/// Liquid Glass segmented button: a blurred glass pill with a glass thumb
/// that slides, stretches and bounces. Supports tap and drag.
class GlassSegmented extends StatefulWidget {
  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;
  const GlassSegmented({
    super.key,
    required this.labels,
    required this.index,
    required this.onChanged,
  });

  @override
  State<GlassSegmented> createState() => _GlassSegmentedState();
}

class _GlassSegmentedState extends State<GlassSegmented> {
  double? _drag;

  @override
  Widget build(BuildContext context) {
    final n = widget.labels.length;
    return LayoutBuilder(
      builder: (context, c) {
        final seg = (c.maxWidth - 8) / n;
        final dragging = _drag != null;
        final pos = _drag ?? widget.index.toDouble();
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (d) {
            final i = ((d.localPosition.dx - 4) / seg).floor().clamp(0, n - 1).toInt();
            widget.onChanged(i);
          },
          onHorizontalDragStart: (_) =>
              setState(() => _drag = widget.index.toDouble()),
          onHorizontalDragUpdate: (d) => setState(() {
            _drag = ((_drag ?? 0) + d.delta.dx / seg)
                .clamp(0.0, n - 1.0)
                .toDouble();
          }),
          onHorizontalDragEnd: (_) {
            final i = (_drag ?? 0).round();
            setState(() => _drag = null);
            widget.onChanged(i);
          },
          onHorizontalDragCancel: () => setState(() => _drag = null),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(26),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
              child: Container(
                height: 52,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(26),
                  color: Colors.white.withAlpha(16),
                  border: Border.all(color: Colors.white.withAlpha(40)),
                ),
                child: Stack(
                  children: [
                    AnimatedPositioned(
                      duration: dragging
                          ? Duration.zero
                          : const Duration(milliseconds: 420),
                      curve: Curves.easeOutBack,
                      left: pos * seg,
                      top: 0,
                      bottom: 0,
                      width: seg,
                      child: AnimatedScale(
                        scale: dragging ? 1.1 : 1.0,
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOut,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(22),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withAlpha(90),
                                C.accent.withAlpha(90),
                              ],
                            ),
                            border: Border.all(color: Colors.white.withAlpha(110)),
                            boxShadow: [
                              BoxShadow(
                                color: C.accent.withAlpha(90),
                                blurRadius: 16,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: Row(
                        children: [
                          for (var i = 0; i < n; i++)
                            Expanded(
                              child: Center(
                                child: AnimatedDefaultTextStyle(
                                  duration: const Duration(milliseconds: 200),
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: pos.round() == i ? Colors.white : C.sub,
                                  ),
                                  child: Text(widget.labels[i]),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class GlassNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const GlassNav({super.key, required this.index, required this.onChanged});

  static const items = [
    (Icons.home_rounded, 'Home'),
    (Icons.calendar_month_rounded, 'Calendar'),
    (Icons.bar_chart_rounded, 'Stats'),
    (Icons.person_rounded, 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(32),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
        child: Container(
          height: 68,
          padding: const EdgeInsets.symmetric(horizontal: 6),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(32),
            color: Colors.white.withAlpha(20),
            border: Border.all(color: Colors.white.withAlpha(46)),
          ),
          child: Row(
            children: [
              for (var i = 0; i < items.length; i++)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => onChanged(i),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          width: 52,
                          height: 30,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: index == i
                                ? C.accent.withAlpha(120)
                                : Colors.transparent,
                          ),
                          child: Icon(
                            items[i].$1,
                            size: 22,
                            color: index == i ? Colors.white : C.sub,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          items[i].$2,
                          style: TextStyle(
                            fontSize: 11,
                            color: index == i ? Colors.white : C.sub,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
