import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'editor.dart';
import 'glass.dart';
import 'models.dart';

Future<bool> confirmDialog(BuildContext context, String title, String msg) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF12164A),
      title: Text(title),
      content: Text(msg),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: const Text('Delete'),
        ),
      ],
    ),
  );
  return ok == true;
}

class DetailScreen extends StatelessWidget {
  final Store store;
  final Dream dream;
  const DetailScreen({super.key, required this.store, required this.dream});

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 10),
        child: Text(t, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
      );

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return Scaffold(
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final d = store.dreams.firstWhere(
            (x) => x.id == dream.id,
            orElse: () => dream,
          );
          final chips = <Widget>[
            for (final t in d.places) Pill(t, icon: Icons.place_outlined),
            for (final t in d.people) Pill(t, icon: Icons.person_outline),
            for (final t in d.tags) Pill(t, icon: Icons.sell_outlined),
          ];
          return NightBackground(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                Stack(
                  children: [
                    Container(
                      height: 280,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: paletteFor(d.id),
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Colors.transparent, C.bg2],
                          ),
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: Center(
                        child: Icon(
                          Icons.nightlight_round,
                          size: 90,
                          color: Colors.white.withAlpha(110),
                        ),
                      ),
                    ),
                    Positioned(
                      top: top + 8,
                      left: 16,
                      child: GlassIcon(Icons.arrow_back, onTap: () => Navigator.pop(context)),
                    ),
                    Positioned(
                      top: top + 8,
                      right: 16,
                      child: GlassIcon(
                        Icons.delete_outline,
                        onTap: () async {
                          final nav = Navigator.of(context);
                          if (await confirmDialog(context, 'Delete this dream?', 'This cannot be undone.')) {
                            nav.pop();
                            store.remove(d.id);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      DText(d.title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 6),
                      Text(
                        '${fmtDay(d.date)} · ${fmtTime(d.date)}',
                        style: const TextStyle(fontSize: 14, color: C.sub),
                      ),
                      if (chips.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        Wrap(spacing: 8, runSpacing: 8, children: chips),
                      ],
                      const SizedBox(height: 18),
                      Glass(
                        radius: 22,
                        padding: const EdgeInsets.all(18),
                        child: DText(
                          d.body.isEmpty ? 'No description.' : d.body,
                          style: const TextStyle(fontSize: 15.5, height: 1.6),
                        ),
                      ),
                      if (d.emotions.isNotEmpty) ...[
                        _section('Emotions'),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [for (final t in d.emotions) Pill(t, icon: Icons.mood)],
                        ),
                      ],
                      if (d.notes.isNotEmpty) ...[
                        _section('Notes'),
                        Glass(
                          radius: 20,
                          child: DText(d.notes, style: const TextStyle(height: 1.5)),
                        ),
                      ],
                      const SizedBox(height: 24),
                      Glass(
                        radius: 26,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => EditorScreen(store: store, dream: d),
                          ),
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.edit, size: 20),
                            SizedBox(width: 8),
                            Text('Edit', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  final Store store;
  const ProfileScreen({super.key, required this.store});

  String _export() {
    final b = StringBuffer();
    for (final d in store.dreams) {
      b.writeln('${d.title} (${fmtDay(d.date)} ${fmtTime(d.date)})');
      if (d.body.isNotEmpty) b.writeln(d.body);
      final extra = [...d.places, ...d.people, ...d.emotions, ...d.tags];
      if (extra.isNotEmpty) b.writeln('Details: ${extra.join(', ')}');
      if (d.notes.isNotEmpty) b.writeln('Notes: ${d.notes}');
      b.writeln();
    }
    return b.toString();
  }

  Widget _action(IconData icon, String label, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Glass(
        onTap: onTap,
        radius: 20,
        child: Row(
          children: [
            Icon(icon, color: C.accent2),
            const SizedBox(width: 14),
            Expanded(child: Text(label, style: const TextStyle(fontSize: 15))),
            const Icon(Icons.chevron_right, color: C.sub),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 150),
      children: [
        const Text('Profile', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
        const SizedBox(height: 24),
        Center(
          child: Column(
            children: [
              const MoonGlow(size: 110),
              const SizedBox(height: 14),
              const Text('Dreamer', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(
                '${store.dreams.length} dreams recorded',
                style: const TextStyle(color: C.sub),
              ),
            ],
          ),
        ),
        const SizedBox(height: 28),
        _action(Icons.copy_all_outlined, 'Copy all dreams as text', () {
          Clipboard.setData(ClipboardData(text: _export()));
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Copied to clipboard')),
          );
        }),
        _action(Icons.delete_sweep_outlined, 'Delete all dreams', () async {
          if (await confirmDialog(context, 'Delete all dreams?', 'This cannot be undone.')) {
            store.clear();
          }
        }),
        const SizedBox(height: 12),
        const Center(
          child: Text('Dream Tracker · Version 2', style: TextStyle(color: C.sub, fontSize: 12)),
        ),
      ],
    );
  }
}
