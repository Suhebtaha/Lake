import 'dart:math';

import 'package:flutter/material.dart';

import 'glass.dart';
import 'liquid.dart';
import 'models.dart';

class StatsScreen extends StatefulWidget {
  final Store store;
  const StatsScreen({super.key, required this.store});

  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  int _range = 1;

  Widget _themeRow(ThemeStat t, int total) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: C.accent.withAlpha(60),
            ),
            child: Icon(kindIcon(t.kind), size: 20, color: C.accent2),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(t.name, style: const TextStyle(fontSize: 15))),
          Text('${t.count}', style: const TextStyle(fontSize: 15)),
          const SizedBox(width: 14),
          SizedBox(
            width: 44,
            child: Text(
              '${(t.count * 100 / total).round()}%',
              textAlign: TextAlign.end,
              style: const TextStyle(color: C.sub, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final days = const [7, 30, 365][_range];
    final from = DateTime.now().subtract(Duration(days: days));
    final ds = widget.store.dreams.where((d) => d.date.isAfter(from)).toList();
    final weeks = days / 7;
    final perDay = List<double>.filled(7, 0);
    for (final d in ds) {
      perDay[d.date.weekday % 7] += 1;
    }
    final avg = ds.length / weeks;
    final themes = themeStats(ds);

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 150),
      children: [
        const Text('Stats', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
        const SizedBox(height: 16),
        GlassSegmented(
          labels: const ['Week', 'Month', 'Year'],
          index: _range,
          onChanged: (i) => setState(() => _range = i),
        ),
        const SizedBox(height: 16),
        Glass(
          radius: 26,
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Dream Frequency',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                  Text(
                    avg.toStringAsFixed(1),
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              const Row(
                children: [
                  Expanded(
                    child: Text('Average per week', style: TextStyle(fontSize: 12, color: C.sub)),
                  ),
                  Text('avg', style: TextStyle(fontSize: 12, color: C.sub)),
                ],
              ),
              const SizedBox(height: 14),
              SizedBox(
                height: 120,
                width: double.infinity,
                child: CustomPaint(
                  painter: LinePainter(perDay.map((v) => v / weeks).toList()),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  for (final n in dayNames)
                    Expanded(
                      child: Center(
                        child: Text(n, style: const TextStyle(fontSize: 10, color: C.sub)),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Glass(
          radius: 26,
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Top Themes', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              if (themes.isEmpty)
                const Text(
                  'Add places, people or tags to your dreams and your top themes will show up here.',
                  style: TextStyle(color: C.sub, height: 1.4),
                ),
              for (final t in themes.take(5)) _themeRow(t, ds.length),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Glass(
          radius: 26,
          padding: const EdgeInsets.all(18),
          child: Row(
            children: const [
              Icon(Icons.nightlight_round, color: C.accent2, size: 34),
              SizedBox(width: 16),
              Expanded(
                child: Text(
                  'Your dreams reveal\nwhat your mind hides.',
                  style: TextStyle(fontSize: 15, height: 1.4),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class LinePainter extends CustomPainter {
  final List<double> v;
  LinePainter(this.v);

  @override
  void paint(Canvas canvas, Size size) {
    final peak = v.reduce(max);
    final maxV = peak == 0 ? 1.0 : peak;
    final pts = <Offset>[
      for (var i = 0; i < v.length; i++)
        Offset(
          size.width * (i + 0.5) / v.length,
          size.height * (1 - 0.15 - 0.7 * v[i] / maxV),
        ),
    ];
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (var i = 0; i < pts.length - 1; i++) {
      final a = pts[i];
      final b = pts[i + 1];
      final mx = (a.dx + b.dx) / 2;
      path.cubicTo(mx, a.dy, mx, b.dy, b.dx, b.dy);
    }
    final fill = Path.from(path)
      ..lineTo(pts.last.dx, size.height)
      ..lineTo(pts.first.dx, size.height)
      ..close();
    canvas.drawPath(
      fill,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.accent.withAlpha(90), C.accent.withAlpha(0)],
        ).createShader(Offset.zero & size),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round
        ..color = C.accent2,
    );
  }

  @override
  bool shouldRepaint(covariant LinePainter oldDelegate) => true;
}
