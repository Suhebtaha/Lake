import 'package:flutter/material.dart';

import 'glass.dart';
import 'models.dart';

class CalendarScreen extends StatefulWidget {
  final Store store;
  final void Function(Dream) onOpen;
  const CalendarScreen({super.key, required this.store, required this.onOpen});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  DateTime _sel = DateTime.now();

  void _shift(int n) =>
      setState(() => _month = DateTime(_month.year, _month.month + n));

  Widget _cell(int day, int days, Set<int> marked) {
    if (day < 1 || day > days) return const SizedBox(height: 46);
    final date = DateTime(_month.year, _month.month, day);
    final sel = sameDay(date, _sel);
    final today = sameDay(date, DateTime.now());
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => _sel = date),
      child: SizedBox(
        height: 46,
        child: Center(
          child: Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: sel ? C.accent : null,
              border: today && !sel ? Border.all(color: C.accent2) : null,
              boxShadow: sel
                  ? [BoxShadow(color: C.accent.withAlpha(120), blurRadius: 14)]
                  : null,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '$day',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Container(
                  width: 4,
                  height: 4,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: marked.contains(day)
                        ? (sel ? Colors.white : C.accent2)
                        : Colors.transparent,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ds = widget.store.dreams;
    final lead = DateTime(_month.year, _month.month, 1).weekday % 7;
    final days = DateTime(_month.year, _month.month + 1, 0).day;
    final rows = ((lead + days) / 7).ceil();
    bool inMonth(Dream d) =>
        d.date.year == _month.year && d.date.month == _month.month;
    final marked = ds.where(inMonth).map((d) => d.date.day).toSet();
    final onDay = ds.where((d) => sameDay(d.date, _sel)).toList();
    final others =
        ds.where((d) => inMonth(d) && !sameDay(d.date, _sel)).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 150),
      children: [
        const Text('Calendar', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
        const SizedBox(height: 16),
        Glass(
          radius: 26,
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => _shift(-1),
                    icon: const Icon(Icons.chevron_left),
                  ),
                  Expanded(
                    child: Text(
                      '${monthNames[_month.month - 1]} ${_month.year}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                    ),
                  ),
                  IconButton(
                    onPressed: () => _shift(1),
                    icon: const Icon(Icons.chevron_right),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  for (final n in dayNames)
                    Expanded(
                      child: Center(
                        child: Text(n, style: const TextStyle(fontSize: 12, color: C.sub)),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              for (var r = 0; r < rows; r++)
                Row(
                  children: [
                    for (var c = 0; c < 7; c++)
                      Expanded(child: _cell(r * 7 + c - lead + 1, days, marked)),
                  ],
                ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        Text(
          'Dreams on ${monthNames[_sel.month - 1].substring(0, 3)} ${_sel.day}',
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 12),
        if (onDay.isEmpty)
          const Text('No dreams on this day', style: TextStyle(color: C.sub)),
        for (final d in onDay)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: DreamTile(d, onTap: () => widget.onOpen(d)),
          ),
        if (others.isNotEmpty) ...[
          const SizedBox(height: 14),
          const Text('Other dreams', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          for (final d in others)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: DreamTile(d, onTap: () => widget.onOpen(d)),
            ),
        ],
      ],
    );
  }
}
