import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const monthNames = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];
const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

String fmtDay(DateTime d) =>
    '${monthNames[d.month - 1].substring(0, 3)} ${d.day}, ${d.year}';

String fmtTime(DateTime d) {
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  final m = d.minute.toString().padLeft(2, '0');
  return '$h:$m ${d.hour >= 12 ? 'PM' : 'AM'}';
}

bool sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

TextDirection dirOf(String s) {
  final m = RegExp(r'[A-Za-z\u0590-\u08FF]').firstMatch(s);
  if (m != null && RegExp(r'[\u0590-\u08FF]').hasMatch(m.group(0)!)) {
    return TextDirection.rtl;
  }
  return TextDirection.ltr;
}

List<String> parseList(String s) => s
    .split(RegExp(r'[,،\n]'))
    .map((t) => t.trim())
    .where((t) => t.isNotEmpty)
    .toSet()
    .toList();

enum Kind { place, person, tag }

IconData kindIcon(Kind k) => switch (k) {
      Kind.place => Icons.place_outlined,
      Kind.person => Icons.person_outline,
      Kind.tag => Icons.sell_outlined,
    };

const artPalettes = [
  [Color(0xFF1B2A6B), Color(0xFF7A5AF8)],
  [Color(0xFF0F3057), Color(0xFF00A8A8)],
  [Color(0xFF3A1C71), Color(0xFFD76D77)],
  [Color(0xFF141E5C), Color(0xFF4F8CFF)],
  [Color(0xFF2B1055), Color(0xFF7597DE)],
];

List<Color> paletteFor(String seed) {
  final n = seed.codeUnits.fold<int>(0, (a, b) => a + b);
  return artPalettes[n % artPalettes.length];
}

class Dream {
  final String id;
  String title;
  String body;
  DateTime date;
  List<String> people;
  List<String> places;
  List<String> emotions;
  List<String> tags;
  String notes;

  Dream({
    required this.id,
    required this.title,
    required this.body,
    required this.date,
    this.people = const [],
    this.places = const [],
    this.emotions = const [],
    this.tags = const [],
    this.notes = '',
  });

  Map<String, Kind> get themes => {
        for (final t in places) t: Kind.place,
        for (final t in people) t: Kind.person,
        for (final t in tags) t: Kind.tag,
      };

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'date': date.toIso8601String(),
        'people': people,
        'places': places,
        'emotions': emotions,
        'tags': tags,
        'notes': notes,
      };

  static List<String> _list(dynamic v) =>
      v == null ? <String>[] : (v as List).map((e) => e.toString()).toList();

  factory Dream.fromJson(Map<String, dynamic> j) => Dream(
        id: j['id'] as String,
        title: j['title'] as String,
        body: j['body'] as String,
        date: DateTime.parse(j['date'] as String),
        people: _list(j['people']),
        places: _list(j['places']),
        emotions: _list(j['emotions']),
        tags: _list(j['tags']),
        notes: (j['notes'] ?? '') as String,
      );
}

class ThemeStat {
  final String name;
  final Kind kind;
  final int count;
  ThemeStat(this.name, this.kind, this.count);
}

List<ThemeStat> themeStats(Iterable<Dream> ds) {
  final counts = <String, int>{};
  final kinds = <String, Kind>{};
  for (final d in ds) {
    d.themes.forEach((t, k) {
      counts[t] = (counts[t] ?? 0) + 1;
      kinds[t] = k;
    });
  }
  final out = [
    for (final e in counts.entries) ThemeStat(e.key, kinds[e.key]!, e.value),
  ];
  out.sort((a, b) => b.count.compareTo(a.count));
  return out;
}

class Store extends ChangeNotifier {
  List<Dream> dreams = [];
  late SharedPreferences _prefs;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    final raw = _prefs.getString('dreams_v2');
    if (raw != null) {
      try {
        dreams = (jsonDecode(raw) as List)
            .map((e) => Dream.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        dreams = [];
      }
      _sort();
    }
  }

  void _sort() => dreams.sort((a, b) => b.date.compareTo(a.date));

  void _save() => _prefs.setString(
      'dreams_v2', jsonEncode(dreams.map((d) => d.toJson()).toList()));

  void upsert(Dream d) {
    final i = dreams.indexWhere((x) => x.id == d.id);
    if (i >= 0) {
      dreams[i] = d;
    } else {
      dreams.add(d);
    }
    _sort();
    _save();
    notifyListeners();
  }

  void remove(String id) {
    dreams.removeWhere((d) => d.id == id);
    _save();
    notifyListeners();
  }

  void clear() {
    dreams = [];
    _save();
    notifyListeners();
  }

  int get thisMonth {
    final n = DateTime.now();
    return dreams
        .where((d) => d.date.year == n.year && d.date.month == n.month)
        .length;
  }

  int get recurring => themeStats(dreams).where((t) => t.count >= 2).length;
}
