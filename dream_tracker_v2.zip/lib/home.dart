import 'package:flutter/material.dart';

import 'glass.dart';
import 'models.dart';

class HomeScreen extends StatelessWidget {
  final Store store;
  final void Function(Dream) onOpen;
  final VoidCallback onNew;
  final VoidCallback onProfile;
  const HomeScreen({
    super.key,
    required this.store,
    required this.onOpen,
    required this.onNew,
    required this.onProfile,
  });

  @override
  Widget build(BuildContext context) {
    final ds = store.dreams;
    final latest = ds.isEmpty ? null : ds.first;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 150),
      children: [
        Row(
          children: [
            const Expanded(
              child: Text(
                'Dream Tracker',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
              ),
            ),
            GlassIcon(Icons.settings_outlined, onTap: onProfile),
          ],
        ),
        const SizedBox(height: 18),
        _lastCard(latest),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _stat(Icons.nightlight_round, '${ds.length}', 'Total Dreams')),
            const SizedBox(width: 10),
            Expanded(child: _stat(Icons.calendar_today_outlined, '${store.thisMonth}', 'This Month')),
            const SizedBox(width: 10),
            Expanded(child: _stat(Icons.autorenew, '${store.recurring}', 'Recurring')),
          ],
        ),
        const SizedBox(height: 24),
        Row(
          children: [
            const Expanded(
              child: Text(
                'Recent Dreams',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
            ),
            GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AllDreamsScreen(store: store, onOpen: onOpen),
                ),
              ),
              child: const Text('See all', style: TextStyle(color: C.accent2)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (ds.isEmpty)
          const Glass(
            child: Text(
              'No dreams yet. Tap the + button to record your first one.',
              style: TextStyle(color: C.sub, height: 1.4),
            ),
          ),
        for (final d in ds.take(5))
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: DreamTile(d, onTap: () => onOpen(d)),
          ),
      ],
    );
  }

  Widget _lastCard(Dream? d) {
    final label = d == null
        ? 'Welcome'
        : (DateTime.now().difference(d.date).inHours < 36
            ? 'Last Night'
            : 'Latest Dream');
    return Glass(
      onTap: d == null ? onNew : () => onOpen(d),
      radius: 26,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
              ),
              const Icon(Icons.chevron_right, color: C.sub),
            ],
          ),
          if (d != null)
            Text(fmtDay(d.date), style: const TextStyle(fontSize: 12, color: C.sub)),
          const SizedBox(height: 24),
          Text(
            d == null ? 'Record your first dream' : 'You dreamed about',
            style: const TextStyle(fontSize: 13, color: C.sub),
          ),
          const SizedBox(height: 4),
          DText(
            d == null ? 'Tap here to start' : d.title,
            maxLines: 2,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  Widget _stat(IconData icon, String value, String label) {
    return Glass(
      radius: 20,
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      child: Column(
        children: [
          Icon(icon, color: C.accent2, size: 22),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 11, color: C.sub),
          ),
        ],
      ),
    );
  }
}

class AllDreamsScreen extends StatefulWidget {
  final Store store;
  final void Function(Dream) onOpen;
  const AllDreamsScreen({super.key, required this.store, required this.onOpen});

  @override
  State<AllDreamsScreen> createState() => _AllDreamsScreenState();
}

class _AllDreamsScreenState extends State<AllDreamsScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NightBackground(
        child: SafeArea(
          child: ListenableBuilder(
            listenable: widget.store,
            builder: (context, _) {
              final q = _q.trim().toLowerCase();
              final list = widget.store.dreams.where((d) {
                return q.isEmpty ||
                    d.title.toLowerCase().contains(q) ||
                    d.body.toLowerCase().contains(q) ||
                    d.themes.keys.any((t) => t.toLowerCase().contains(q));
              }).toList();
              return ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
                children: [
                  Row(
                    children: [
                      GlassIcon(Icons.arrow_back, onTap: () => Navigator.pop(context)),
                      const SizedBox(width: 14),
                      const Text(
                        'All Dreams',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Glass(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: TextField(
                      onChanged: (v) => setState(() => _q = v),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        icon: Icon(Icons.search, color: C.sub),
                        hintText: 'Search dreams',
                        hintStyle: TextStyle(color: C.sub),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (list.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(30),
                      child: Center(
                        child: Text('No dreams found', style: TextStyle(color: C.sub)),
                      ),
                    ),
                  for (final d in list)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: DreamTile(d, onTap: () => widget.onOpen(d)),
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
